const express = require('express');
const cors = require('cors');
const { exec } = require('child_process');

const app = express();
app.use(cors());
app.use(express.json()); // Middleware to parse JSON bodies

app.post('/run', (req, res) => {
  const { command } = req.body;

  if (!command) {
    return res.status(400).json({ error: 'Command is required' });
  }

  exec(command, (error, stdout, stderr) => {
    if (error) {
      return res.status(500).json({ error: error.message });
    }
    if (stderr) {
      return res.status(500).json({ stderr });
    }
    res.json({ stdout });
  });
});

const PORT = process.env.PORT || '3000'; // Ensure PORT is a string
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
